$("document").ready(function(){
    alert("test from jquery as a sdas"); 
 });
 